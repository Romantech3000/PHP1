<?php

ob_start();
echo "<br><h1 id='top'>Урок 3. ДЗ</h1>";
echo "<br><h2 id='task1'>Задание 1</h2>";

$i = 0;
while ($i < 101) {
    if (!($i % 3)) echo $i."&nbsp;";
    $i++;
}


echo "<br><hr><h2 id='task2'>Задание 2</h2>";

$i = 0;
do {
    if ($i == 0) echo $i." - это ноль<br>";
    elseif ($i & 1) echo $i." - нечётное число<br>";
        else echo $i." - чётное число<br>";
} while ($i++ < 10);

echo "<br><hr><h2 id='task3'>Задание 3</h2>";


$locations = [
    "Саратовская" => ["Аркадак", "Аткарск",  "Балаково", "Берзовский"],
    "Свердловская" => ["Артёмовский", "Асбест"],
    "Амурская" => ["Белогорск", "Благовещенск", "Завитинск", "Зея", "Райчихинск"],
    "Московская" => ["Реутов", "Волоколамск", "Химки", "Монино"],
    "Смоленская" => ["Рудня", "Велиж", "Вязьма"],
    "Волгоградская" => ["Дубовка", "Жирновск", "Калач-На-Дону", "Камышин"],
    "Ленинградская" => ["Кингисепп", "Кириши", "Коммунар", "Лодейное Поле", "Луга"]
];

foreach ($locations as $region => $places) {
    echo "{$region} область:<br>";
    $numElems = count($places);
    foreach ($places as $idx => $town) {
        echo "{$town}";
        if ($idx < $numElems - 1) echo ", ";
    }
    echo "<br><br>";
}


echo "<br><hr><h2 id='task4'>Задание 4</h2>";

$alphabet = [
    'а' => 'a',   'б' => 'b',   'в' => 'v',
    'г' => 'g',   'д' => 'd',   'е' => 'e',
    'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
    'и' => 'i',   'й' => 'y',   'к' => 'k',
    'л' => 'l',   'м' => 'm',   'н' => 'n',
    'о' => 'o',   'п' => 'p',   'р' => 'r',
    'с' => 's',   'т' => 't',   'у' => 'u',
    'ф' => 'f',   'х' => 'h',   'ц' => 'c',
    'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
    'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
    'э' => 'e',   'ю' => 'yu',  'я' => 'ya'
];


function transliterate($str, $alphabet) {
    $strArr = preg_split('//u', $str, NULL, PREG_SPLIT_NO_EMPTY);
    foreach($strArr as $idx => $item) {
        $lowercase = mb_strtolower($item);

        if (array_key_exists($lowercase, $alphabet)) {
            $strArr[$idx] = ($lowercase != $item) ?
                mb_strtoupper(mb_substr($alphabet[$lowercase], 0, 1)) . mb_substr($alphabet[$lowercase], 1, NULL)
                : $alphabet[$item];
        }
    }
    return implode($strArr); // not 100% multibyte safe
}

echo transliterate('Мама мыла раму! Чукча жарил щавель.', $alphabet), '<br>';

echo "<br><hr><h2 id='task5'>Задание 5</h2>";

function replaceSpaces($str) {
    return str_replace(' ','_', $str);
}

//str_replace might be not 100% safe with multibyte strings
function replaceSpacesMB($str) {
    return mb_ereg_replace('\s','_', $str);
}

echo replaceSpaces('Съешь ещё этих мягких французских булок, да выпей чаю'), '<br>';
echo replaceSpacesMB('Съешь ещё этих мягких французских булок, да выпей чаю'), '<br>';

echo "<br><hr><h2 id='task6'>Задание 6</h2><p>Меню сверху</p>";


echo "<br><hr><h2 id='task7'>Задание 7</h2>";

for ($i = 0; $i <= 9; print($i++."&nbsp;")) {}


echo "<br><hr><h2 id='task8'>Задание 8</h2>";

foreach ($locations as $region => $places) {
    echo "{$region} область:<br>";
    $numElems = count($places);
    foreach ($places as $idx => $town) {
        if (mb_substr($town, 0, 1) == "К") {
            echo "{$town}";
            if ($idx < $numElems - 1) echo ", ";
        }
    }
    echo "<br><br>";
}


echo "<br><hr><h2 id='task9'>Задание 9</h2>";

$str1 = 'Мама мыла раму! Чукча жарил щавель.';
$str2 = 'Съешь ещё этих мягких французских булок, да выпей чаю';

echo $str1, '<br>';
echo replaceSpacesMB(transliterate($str1, $alphabet)), '<br><br>';
echo $str2, '<br>';
echo transliterate(replaceSpacesMB($str2), $alphabet), '<br><br>';


$content = ob_get_clean();

// main menu

$menuArray = [
    [
        "name" => "Задания","href" => "#",
        "submenu" => [
            ['id' => '1', 'href' => '#task1', 'name' => 'Задание 1'],
            ['id' => '2', 'href' => '#task2', 'name' => 'Задание 2'],
            ['id' => '3', 'href' => '#task3', 'name' => 'Задание 3'],
            ['id' => '4', 'href' => '#task4', 'name' => 'Задание 4'],
            ['id' => '5', 'href' => '#task5', 'name' => 'Задание 5'],
            ['id' => '6', 'href' => '#task6', 'name' => 'Задание 6'],
            ['id' => '7', 'href' => '#task7', 'name' => 'Задание 7'],
            ['id' => '8', 'href' => '#task8', 'name' => 'Задание 8'],
            ['id' => '9', 'href' => '#task9', 'name' => 'Задание 9']
        ]
    ],
    [
        "name" => "Просто пункт","href" => "#"
    ]
];



//<li><a href="task1">Задание 1</a></li>
function makeMenu($arr, $lvl = 0) {
    if ($lvl == 0) $content = "<ul class=\"main-menu\">";
    else $content = "<ul>";
    foreach ($arr as $item) {
        $content .= ($lvl == 0)? "<li class=\"main-menu__top-li\">" : "<li>";
        $content .= "<a href=\"{$item['href']}\">{$item['name']}</a>";
        if (array_key_exists('submenu', $item)) {
            $content .= makeMenu($item['submenu'], $lvl+1);
        }
        $content .= "</li>";
    }
    $content .= "</ul>";
    return $content;
}

ob_start();
echo makeMenu($menuArray);
$menu = ob_get_clean();

// IIFE test OK
echo (function ($template, $content, $menu) {
    ob_start();
    include $template;
    return ob_get_clean();
}) ('layout.php', $content, $menu);




